package com.example.aidost

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { AiDostScreen(onSpeak = { speak(it) }) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("fa", "IR")
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aidost_reply")
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AiDostScreen(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val messages = remember {
        mutableStateListOf(
            ChatMessage("سلام! من دستیار هوشمند تو هستم. برای اتصال به هوش مصنوعی، سرور را تنظیم می‌کنیم.", false)
        )
    }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("نسخه آزمایشی") }
    val listState = rememberLazyListState()

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = spoken
    }

    fun startSpeech() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            status = "تشخیص گفتار روی این دستگاه در دسترس نیست."
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "صحبت کن…")
        }
        speechLauncher.launch(intent)
    }

    fun sendMessage() {
        val text = input.trim()
        if (text.isEmpty() || busy) return
        messages.add(ChatMessage(text, true))
        input = ""
        busy = true
        status = "در حال پاسخ‌گویی…"
        scope.launch {
            // This starter uses a local placeholder until you create a secure backend.
            // Never put a private AI API key directly in an Android app.
            val reply = withContext(Dispatchers.IO) {
                requestAssistantReply(text)
            }
            messages.add(ChatMessage(reply, false))
            status = "آماده"
            busy = false
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("AI Dost", fontWeight = FontWeight.Bold)
                        Text(status, style = MaterialTheme.typography.labelSmall)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(12.dp)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { message ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
                    ) {
                        Surface(
                            color = if (message.fromUser)
                                MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.widthIn(max = 310.dp)
                        ) {
                            Column(Modifier.padding(12.dp)) {
                                Text(message.text)
                                if (!message.fromUser) {
                                    TextButton(onClick = { onSpeak(message.text) }) {
                                        Text("🔊 خواندن پاسخ")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("پیامت رو بنویس…") },
                    maxLines = 4
                )
                Spacer(Modifier.width(6.dp))
                Column {
                    Button(onClick = { startSpeech() }, contentPadding = PaddingValues(10.dp)) {
                        Text("🎙")
                    }
                    Spacer(Modifier.height(4.dp))
                    Button(
                        onClick = { sendMessage() },
                        enabled = input.isNotBlank() && !busy,
                        contentPadding = PaddingValues(10.dp)
                    ) {
                        Text("➤")
                    }
                }
            }
            Text(
                "برای پاسخ هوشمند واقعی، باید آدرس بک‌اند امن را در کد تنظیم کنیم.",
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}

private fun requestAssistantReply(userText: String): String {
    // Placeholder response. Replace this with a request to YOUR backend.
    // Backend URL and AI provider credentials should live on the server, not in this app.
    return "پیامت دریافت شد: «$userText»\n\nاین نسخه هنوز به مدل هوش مصنوعی وصل نشده. مرحله بعد یک بک‌اند امن می‌سازیم تا پاسخ واقعی، جست‌وجوی وب و ساخت تصویر اضافه شوند."
}
